package App;

import UserDef.*;
import UserDef.Enums.*;
import java.util.*;

public class ResourceManager {

    private int SITE_COUNT = 10;
    private int VARIABLE_COUNT = 20;

    private ArrayList<Site> sites = new ArrayList<>();

    // helper methods
    public String generateLockTableKey(int variableID, LOCK lockType) {
        return variableID + lockType.name();
    }

    public String generateAltLockTableKey(int variableID, LOCK lockType) {
        return variableID + ((lockType == LOCK.READ) ? LOCK.WRITE.name() : LOCK.READ.name());
    }

    public void initializeResources() {
        for (int i = 1; i <= SITE_COUNT; i++)
            sites.add(new Site(i));
        for (int i = 1; i <= VARIABLE_COUNT; i++) {
            Variable v = new Variable(i, 10 * i);
            if (i % 2 == 0) {
                for (Site s : sites) {
                    s.addVariable(v);
                }
            }
            else {
                sites.get(i % 10).addVariable(v);
            }
        }
    }

    // a resource is available if locks can be obtained for it
    public boolean checkResourceAvailability(int variableID, int transactionID, LOCK lockType) {
        boolean resourceIsAvaialable = false;
        for (Site s: sites) {
            if (s.getStatus() == STATUS.UP) {
                // only look in active sites
                for (Variable v: s.getSiteVariables()) {
                    //  check lock table if variable is present in site
                    if (v.getID() == variableID) {
                        String key = generateLockTableKey(variableID, lockType);
                        String alt = generateAltLockTableKey(variableID, lockType);
                        if (lockType == LOCK.READ) {
                            // read locks can be obtained only if there is no transaction using a write lock
                            // if alt key exists there is a write lock else true (no need to check other sites)
                            return !s.getLockTable().containsKey(alt);
                        }
                        else {
                            // write locks can be obtained if there is no read or write locks on variable
                            // we wont return in else because we need to check for locks on all other sites
                            if (s.getLockTable().containsKey(key) || s.getLockTable().containsKey(alt))
                                return false;
                            else
                                resourceIsAvaialable = true;
                        }
                    }
                }
            }
        }
        // will be false if variable is not available in any site
        return resourceIsAvaialable;
    }

    public void failSite(int siteId) {
        // on failing, clear the lock table and set status as DOWN
        sites.get(siteId).getLockTable().clear();
        sites.get(siteId).setStatus(STATUS.DOWN);
    }

    public void recoverSite(int siteId) {
        // on recovery, set status as UP
        sites.get(siteId).setStatus(STATUS.UP);
    }

    public void dump() {
        for (Site s: sites) {
            System.out.print(s + " - ");
            for (Variable v: s.getSiteVariables())
                System.out.print(v + ", ");
            System.out.println();
        }
    }
}
