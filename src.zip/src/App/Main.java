package App;

import UserDef.Error;
import java.io.File;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        try {
            if (args.length > 0) {
                TransactionManager transactionManager = new TransactionManager();
                File file = new File(args[0]);
                if (!file.exists())
                    throw new Error("ERROR: Input file does not exist");
                try (Scanner in = new Scanner(file)) {
                    while (in.hasNext()) {
                        // read each transaction line by line
                        String line = in.nextLine().trim();
                        if (line.indexOf("//") == -1) { // ignores comments
                            // initializes transaction based on input line
                            transactionManager.execute(line);
                        }
                    }
                }
            }
            else
                throw new Error("ERROR: No arguments passed. Please include the input file in the argument");
        }
        catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
        finally {
            System.out.println("Exiting program.");
        }
    }
}
