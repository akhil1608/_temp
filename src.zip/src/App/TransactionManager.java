package App;

// import UserDef.*;
// import java.util.*;

public class TransactionManager {

    private static int timeCounter = 0;
    private ResourceManager resourceManager;

    TransactionManager() {
        // setup resource manager (and resources) as soon as transaction manager is invoked
        resourceManager = new ResourceManager();
        resourceManager.initializeResources();
    }

    public void execute(String task) {
        // update time on each operation
        timeCounter++;
        /* extract details of the task. taskInfo could represent any of: 
            (values are assumed for easy explanation)
            transaction id = 2
            site id = 5
            (variable id, transaction id) = (4, 2) [READ operations]
            (variable id, transaction id, value) = (4, 2, 105) [WRITE operations]
        */
        String taskInfo = task.substring((task.indexOf("(") + 1), (task.indexOf(")"))).trim();
        if (task.indexOf("begin(") != -1) {
            // begin transaction 2
            beginTxn(taskInfo, false);
        }
        else if (task.indexOf("beginRO(") != -1) {
            // begin transaction ..
            beginTxn(taskInfo, true);
        }
        else if (task.indexOf("end(") != -1) {
            // end transaction 2
            endTxn(taskInfo);
        }
        else if (task.indexOf("fail(") != -1) {
            // fail site 5
            resourceManager.failSite(Integer.parseInt(taskInfo));
        }
        else if (task.indexOf("recover(") != -1) {
            // recover a failed site 5
            resourceManager.recoverSite(Integer.parseInt(taskInfo));
        }
        else if (task.indexOf("R(") != -1) {
            String[] token = taskInfo.split(",");
            // read variable 4 for transaction 2
            readTxn(token[0], Integer.parseInt(token[1]), timeCounter);
        }
        else if (task.indexOf("W(") != -1) {
            // String[] token = taskInfo.split(",");
            // write variable 4 with value 105 for transaction 2 at time = timeCounter
            // writeTxn(token[0], Integer.parseInt(token[1]), Integer.parseInt(token[2]), timeCounter);
        } 
        else if (task.indexOf("dump(") != -1) {
            // print current values of variables across sites
            resourceManager.dump();
        }
    }

    private void beginTxn(String txnId, boolean isReadOnly) {
    }

    private void endTxn(String txnId) {
    }

    private void readTxn(String txnId, int varId, int time) {
    }
}