package Test;

import java.util.*;

import App.ResourceManager;
import UserDef.Site;
import UserDef.Transaction;

public class Transaction_Manager {

    private static int timeCounter = 0;

    private static HashMap<String, Transaction> txnMap = new HashMap<>();
    private static ResourceManager resourceManager = new ResourceManager();
    private static List<Operations> operationsOnWaitList = new ArrayList<>();
    private static Map<String, Set<String>> waitsForGraph = new HashMap<>();

    public void initalizeTransaction(String line) {
        timeCounter++;

        String txnDetail = line.substring((line.indexOf("(") + 1), (line.indexOf(")"))).trim();
        if(line.indexOf("begin(") != -1) {
            beginTxn(txnDetail, false);
        } else if(line.indexOf("beginRO(") != -1) {
            beginTxn(txnDetail, true);
        } else if(line.indexOf("end(") != -1) {
            endTxn(txnDetail);
        } else if(line.indexOf("fail(") != -1) {
            failSite(Integer.parseInt(txnDetail));
        } else if(line.indexOf("recover(") != -1) {
            recoverSite(Integer.parseInt(txnDetail));
        } else if(line.indexOf("R(") != -1) {
            String[] token = txnDetail.split(",");
            readTxn(token[0], Integer.parseInt(token[1]), timeCounter);
        } else if(line.indexOf("W(") != -1) {
            String[] token = txnDetail.split(",");
            writeTxn(token[0], Integer.parseInt(token[1]), Integer.parseInt(token[2]), timeCounter);
        } else if(line.indexOf("dump(") != -1) {
            dump();
        }
    }

    private void beginTxn(String txnId, boolean isReadOnly) {
        if(!txnMap.containsKey(txnId)) {
            Transaction txn = new Transaction(txnId, isReadOnly, timeCounter);
            txnMap.put(txnId, txn);
            waitsForGraph.put(txnId, new HashSet<>());
        }
    }

    private void endTxn(String txnId) {
        if(txnMap.get(txnId).isAborted()) {
            abortTxn(txnId);
            System.out.println(String.format("%s was aborted during previous site failure", txnId));
        } else {
            commitTxn(txnId);
        }
    }

    private void failSite(int siteId) {
        resourceManager.failOperation(siteId);
        for(Transaction txn : txnMap.values()) {
            if(txn.isSiteAccessed(siteId)) {
                txn.setAborted(true);
            }
        }
    }

    private void recoverSite(int siteId) {
        resourceManager.recoverOperation(siteId);
        retryWaitListedOperations();
    }

    private void readTxn(Operations op) {
        readTxn(op.getTxnId(), op.getVarId(), op.getTime());
    }

    private void readTxn(String txnId, int varId, int time) {
        if(txnMap.containsKey(txnId) && !txnMap.get(txnId).isAborted()) {
            Transaction txn = txnMap.get(txnId);
            Operations operation = new Operations(txnId, varId, 0, time, "READ_OPERATION");

            String blockingTxnId = null;
            for(Operations op : operationsOnWaitList) {
                if(time <= op.getTime()) {
                    break;
                } else if(op.getType().equals("WRITE_OPERATION") && op.getTxnId() != txnId && op.getVarId() == varId) {
                    blockingTxnId = op.getTxnId();
                }
            }

            if(blockingTxnId == null) {
                boolean readSuccessfully = resourceManager.readOperation(txn, operation);
                if(readSuccessfully) {
                    return;
                }
                if(waitsForGraph.containsKey(txnId)) {
                    for(Site site : resourceManager.getSiteMap().values()) {
                        if(site.isSiteUp() && site.hasVariable(varId)) {
                            List<String> conflicTxnIdsList = site.getLockedTxns(varId);
                            conflicTxnIdsList.removeAll(Collections.singleton(txnId));
                            waitsForGraph.get(txnId).addAll(conflicTxnIdsList);
                        }
                    }
                }
            } else {
                if(waitsForGraph.containsKey(txnId)) {
                    waitsForGraph.get(txnId).add(blockingTxnId);
                }
            }

            if(!txn.isBlocked()) {
                operationsOnWaitList.add(operation);
                txn.setBlocked(true);
                System.out.println(String.format("%s blocked", txnId));
            }
            detectDeadlock(txnId);
        }
    }

    private void writeTxn(Operations op) {
        writeTxn(op.getTxnId(), op.getVarId(), op.getValue(), op.getTime());
    }

    private void writeTxn(String txnId, int varId, int value, int time) {
        if(txnMap.containsKey(txnId) && !txnMap.get(txnId).isAborted()) {
            Transaction txn = txnMap.get(txnId);
            Operations operation = new Operations(txnId, varId, value, time, "WRITE_OPERATION");

            String blockingTxnId = null;
            for(Operations op : operationsOnWaitList) {
                if(time <= op.getTime()) {
                    break;
                } else if(op.getTxnId() != txnId && op.getVarId() == varId) {
                    blockingTxnId = op.getTxnId();
                }
            }

            if(blockingTxnId != null && waitsForGraph.get(blockingTxnId).size() > 0) {
                if(waitsForGraph.containsKey(txnId)) {
                    waitsForGraph.get(txnId).add(blockingTxnId);
                }
            } else {
                boolean isWriteSuccessful = resourceManager.writeOperation(txn, operation, value);
                if(isWriteSuccessful) {
                    return;
                }
                if(waitsForGraph.containsKey(txnId)) {
                    for(Site site : resourceManager.getSiteMap().values()) {
                        if(site.isSiteUp() && site.hasVariable(varId)) {
                            List<String> conflicTxnIdsList = site.getLockedTxns(varId);
                            conflicTxnIdsList.removeAll(Collections.singleton(txnId));
                            waitsForGraph.get(txnId).addAll(conflicTxnIdsList);
                        }
                    }
                }
            }

            if(!txn.isBlocked()) {
                operationsOnWaitList.add(operation);
                txn.setBlocked(true);
                System.out.println(String.format("%s blocked", txnId));
            }
            detectDeadlock(txnId);
        }
    }

    public static void dump() {
        resourceManager.dump();
    }

    private void detectDeadlock(String txnId) {
        if(waitsForGraph.containsKey(txnId)) {
            List<String> cycle = new ArrayList<>();

            if(hasDeadLock(txnId, cycle, new ArrayList<>())) {
                int timestamp = -1;
                String youngestTxnId = null;
                for(String blockingTxnId : cycle) {
                    if(txnMap.get(blockingTxnId).getStartTime() > timestamp) {
                        timestamp = txnMap.get(blockingTxnId).getStartTime();
                        youngestTxnId = blockingTxnId;
                    }
                }
                System.out.println(String.format("%s aborts due to deadlock", youngestTxnId));
                abortTxn(youngestTxnId);
            }
        }
    }

    private boolean hasDeadLock(String txnId, List<String> cycle, List<String> visited) {
        boolean hasDeadLock = false;
        if(cycle.contains(txnId)) {
            hasDeadLock = true;
        } else if(!visited.contains(txnId)) {
            cycle.add(txnId);
            visited.add(txnId);
            for(String blockingTxnId : waitsForGraph.get(txnId)) {
                if(hasDeadLock(blockingTxnId, cycle, visited)) {
                    hasDeadLock = true;
                }
            }
            cycle.remove(Integer.valueOf(txnId));
        }
        return hasDeadLock;
    }

    private void abortTxn(String txnId) {
        resourceManager.abortOperation(txnId);

        for(Operations op : operationsOnWaitList) {
            if(op.getTxnId().equals(txnId)) {
                operationsOnWaitList.remove(op);
            }
        }

        txnMap.remove(txnId);
        waitsForGraph.remove(txnId);
        for(Set txnIds : waitsForGraph.values()) {
            txnIds.remove(txnId);
        }
        retryWaitListedOperations();
    }

    private void commitTxn(String txnId) {
        resourceManager.commitOperation(txnMap.get(txnId), timeCounter);

        txnMap.remove(txnId);
        waitsForGraph.remove(txnId);
        for(Set txnIds : waitsForGraph.values()) {
            txnIds.remove(txnId);
        }
        retryWaitListedOperations();
    }

    private void retryWaitListedOperations() {
        Iterator<Operations> itr = operationsOnWaitList.iterator();
        while(itr.hasNext()) {
            Operations op = itr.next();
            if(txnMap.containsKey(op.getTxnId())) {
                if("WRITE_OPERATION".equals(op.getType())) {
                    writeTxn(op);
                } else {
                    readTxn(op);
                }
                if(!txnMap.get(op.getTxnId()).isBlocked()) {
                    itr.remove();
                }
            }
        }
    }

}