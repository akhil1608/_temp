package UserDef;

import UserDef.Enums.STATUS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Site {

    private int ID;
    private STATUS status;
    private int failedTime;
    private int recoveredTime;
    private ArrayList<Variable> siteVariables;
    private HashMap<String, ArrayList<Integer>> lockTable;
    
    public Site(int ID) {
        this.ID = ID;
        this.status = STATUS.UP;
        this.failedTime = -1;
        this.recoveredTime = -1;
        this.siteVariables = new ArrayList<>();
        this.lockTable = new HashMap<>();
    }

    public int getID() {
        return this.ID;
    }
    
    public STATUS getStatus() {
        return this.status;
    }

    public int getFailedTime() {
        return this.failedTime;
    }

    public int getRecoveredTime() {
        return this.recoveredTime;
    }

    public ArrayList<Variable> getSiteVariables() {
        return this.siteVariables;
    }

    public HashMap<String, ArrayList<Integer>> getLockTable() {
        return this.lockTable;
    }

    public void addLock(String key, int transactionID) {
        if (this.lockTable.containsKey(key))
            this.lockTable.get(key).add(transactionID);
        else
            this.lockTable.put(key, new ArrayList<Integer>(Arrays.asList(transactionID)));
    }
    
    public void setStatus(STATUS status) {
        this.status = status;
    }

    public void setFailedTime(int failedTime) {
        this.failedTime = failedTime;
    }

    public void setRecoveredTime(int recoveredTime) {
        this.recoveredTime = recoveredTime;
    }

    public void addVariable(Variable v) {
        this.siteVariables.add(v);
    }

    @Override
    public String toString() {
        return String.format("site %1$d", this.ID);
    }
}
