package UserDef;

import java.util.HashSet;

public class Transaction {
    private String txnId;
    private boolean isReadOnly;
    private int startTime;
    private HashSet<Integer> accessedSites;
    private boolean isBlocked;
    private boolean isAborted;

    public Transaction(String txnId, boolean isReadOnly, int startTime) {
        this.txnId = txnId;
        this.isReadOnly = isReadOnly;
        this.startTime = startTime;
        this.accessedSites = new HashSet<>();
        this.isBlocked = false;
        this.isAborted = false;
    }

    public String getTxnId() {
        return txnId;
    }

    public boolean isReadOnly() {
        return isReadOnly;
    }

    public int getStartTime() {
        return startTime;
    }

    public HashSet<Integer> getAccessedSites() {
        return accessedSites;
    }

    public boolean isBlocked() {
        return isBlocked;
    }

    public boolean isAborted() {
        return isAborted;
    }

    public void setSites(int siteId) {
        accessedSites.add(siteId);
    }

    public boolean isSiteAccessed(int siteId) {
        return accessedSites.contains(siteId);
    }

    public void setBlocked(boolean blocked) {
        isBlocked = blocked;
    }

    public void setAborted(boolean aborted) {
        isAborted = aborted;
    }
}
