package UserDef;

public class Enums {
    public enum STATUS {
        UP,
        DOWN
    }
    public enum LOCK {
        READ,
        WRITE
    }
}
