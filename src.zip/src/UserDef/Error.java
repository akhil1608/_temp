package UserDef;

// for custom exceptions (errors)
public class Error extends Exception {
    public Error(String s) {
        super(s);
    }
}
