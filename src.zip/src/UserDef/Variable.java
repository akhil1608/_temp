package UserDef;

public class Variable {

    private int ID;
    private int value;
    private int version;

    public Variable(int ID, int value) {
        this.ID = ID;
        this.value = value;
        this.version = 0;
    }

    public int getID() {
        return this.ID;
    }

    public int getValue() {
        return this.value;
    }

    public int getVersion() {
        return this.version;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return String.format("x%1$d: %2$d", this.ID, this.value);
    }
}